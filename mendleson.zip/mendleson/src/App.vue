<template>
  <div id="app">
    <!-- Header
    <Header></Header> -->

    <transition name="fade" mode="out-in">
        <router-view/>
    </transition>

    <!-- Footer -->
    <Footer></Footer>

    <!-- Scrol-lTop and page-Loader -->
    <div>
      <!-- Scroll top -->
      <b-button href="#" variant="primary" @click="scrollTop" v-show="scrollArrow" class="rounded-pill shadow-none scroll-top mr-4 mb-5"><b-icon icon="chevron-up"></b-icon></b-button>
    </div>
  </div>
</template>

<script>
  // import footer
  import Footer from './components/footer'
  export default {
    name: 'App',
    components: {Footer},
    
    metaInfo: {
      title: 'Default App Title',
      titleTemplate: '%s | vue-meta Example App',
      htmlAttrs: {
        lang: 'en-US'
      },
      meta: [
        { charset: 'utf-8' },
        { name: 'description', content: 'An example Vue application with vue-meta.' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' }
      ]
    },
    

    data(){
      return{
        // Scroll arrow
        scrollArrow: false,
      }
    },

    mounted: function () {
      // Scroll arrow
      window.addEventListener('scroll', this.scrollarrow)
    },
    beforeDestroy: function () {
      // Scroll arrow
      window.removeEventListener('scroll', this.scrollarrow)
    },
    methods: {
      // click scroll top
      scrollTop: function () {
        this.intervalId = setInterval(() => {
          if (window.pageYOffset === 0) {
            clearInterval(this.intervalId)
          }
          window.scroll(0, window.pageYOffset - 50)
        }, 20)
      },
      // Scroll arrow
      scrollarrow: function (e) {
        this.scrollArrow = window.scrollY > 850
      },
    }
  }
</script>

<style>
  /*google fonts*/
  @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

  /* heading and paragraph Colors and sizes */
  h1,h2,h3,h4,h5,h6{
    font-family: 'Rubik', sans-serif !important;
    color: #000000 !important;
  }
  h1{
    font-weight: 500 !important;
    font-size: 48px !important;
    line-height: 57px !important;
  }
  h2{
    font-weight: 500 !important;
    font-size: 42px !important;
    line-height: 50px !important;
  }
  h3{
    font-weight: 500 !important;
    font-size: 35px !important;
    line-height: 50px !important;
  }
  p{
    font-family: 'Rubik', sans-serif !important;
    font-style: normal;
    font-weight: 400 !important;
    font-size: 18px !important;
    line-height: 28px !important;
    color: #2C2C2C !important;
  }

  /* Colors */
  .bg-blue{background-color: #1883b2;}
  .bg-black{background-color: #000;}
  .margin-top1{margin-top: 170px;}
  .margin-top2{margin-top: 300px !important;}
  .text-hvr1{color: #000; text-decoration: none;}
  .text-hvr1:hover{color: #1883b2; text-decoration: none;}

  /* Mobile Responsive */
  @media screen and (max-width: 767px){
    .margin-top1{margin-top: 0px;}
    .margin-top2{margin-top: 0px !important;}
  }
  @media screen and (max-width: 320px){
    h1{
      font-weight: 500 !important;
      font-size: 20px !important;
      line-height: 37px !important;
    }
    h2{
      font-weight: 500 !important;
      font-size: 17px !important;
      line-height: 50px !important;
    }
    h3{
      font-weight: 500 !important;
      font-size: 20px !important;
      line-height: 50px !important;
    }
  }

  /* scroll top */
  .scroll-top{
    padding: 15px;
    padding-left: 17px !important;
    padding-right: 17px !important;
    background-color: #1883b2;
    right: 0; 
    bottom: 0; 
    position: fixed; 
    z-index: 999;
  }

  /* page fade animation */
  .fade-enter-active,
  .fade-leave-active {
    transition-duration: 0.3s;
    transition-property: opacity;
    transition-timing-function: ease;
  }

  .fade-enter,
  .fade-leave-active {
    opacity: 0
  }
</style>
