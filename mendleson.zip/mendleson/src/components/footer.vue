<template>
    <!--footer-->
    <div class="text-left">
        <b-container>
            <footer class="foot text-left py-5">
                <b-container class="col-md-11 mx-auto">
                    <b-row>
                        <b-col lg="3" sm="6" class="mt-4">
                            <h6 class="h5">Social</h6>
                            <div class="mt-4">
                                <p class="mb-2 mr-3 mt-4">
                                    <a href="#" class="text-decoration-none"><b-img class="mr-2" fluid :src="require('@/assets/images/facebook1.png')"></b-img> Facebook</a>
                                </p>
                                <p class="mb-2 mr-3">
                                    <a href="#" class="text-decoration-none"><b-img class="mr-2" fluid :src="require('@/assets/images/linkedin1.png')"></b-img> Linkedin</a>
                                </p>
                                <p class="mb-2 mr-3">
                                    <a href="#" class="text-decoration-none"><b-img class="rounded-pill mr-2 bg-white p-1" fluid :src="require('@/assets/images/search 1.jpg')"></b-img> Google +</a>
                                </p>
                            </div>
                        </b-col>
                        <b-col lg="2" sm="6" class="mt-4">
                            <h6 class="h5">Explore</h6>
                            <p class="mb-2 mr-3 mt-4">
                                <a href="#" class="text-decoration-none"> Services</a>
                            </p>
                            <p class="mb-2 mr-3">
                                <a href="#" class="text-decoration-none"> Team</a>
                            </p>
                            <p class="mb-2 mr-3">
                                <a href="#" class="text-decoration-none"> Clients</a>
                            </p>
                        </b-col>

                        <b-col lg="3" sm="6" class="mt-4">
                            <h6 class="h5">Contact</h6>

                            <div class="mt-4">
                                <p> Lorem Ipsum dummy address </p>
                                <p><span>used for display</span></p>
                                <p><a href="tel:1234567890" class="text-decoration-none footer-link-color"> 1234567890</a></p>
                            </div>
                        </b-col>

                        <b-col lg="4" sm="6" class="mt-4">
                            <h6 class="h5">Email</h6>
                            <p class="mt-4">
                                <a href="mailto:mendlesoncommunication@email.com" class="text-decoration-none footer-link-color"> mendlesoncommunication @email.com</a>
                            </p>
                        </b-col>
                    </b-row>
                </b-container>
            </footer>

            <div class="foot py-3">
                <b-container>
                    <b-row>
                        <b-col class="text-center">
                            <p class="mb-0">© Copyright 2018 Mendleson Communication Pty Ltd </p>
                        </b-col>
                    </b-row>
                </b-container>
            </div>  
        </b-container>
    </div>
</template>

<script>
    export default {
        name: 'Footer',
        data(){
            return{}
        }
    }
</script>

<style>
    footer{background-color: #BFDBFF;}
    footer p{ 
        font-weight: 400 !important;
        font-size: 14px !important;
        line-height: 31px !important;
        color: #2C2C2C !important; 
    }
    .foot p{ 
        font-weight: 400 !important;
        font-size: 14px !important;
        line-height: 31px !important;
        color: #2C2C2C !important; 
    }
    .foot a{
        font-weight: 400 !important;
        font-size: 14px !important;
        line-height: 31px !important;
        color: #2C2C2C; 
        font-family: 'Rubik', sans-serif !important;
    }
    .foot a:hover{color: #1883b2;}
</style>