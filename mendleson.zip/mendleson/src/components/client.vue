<template>
  <div class="text-left bg-white">
    <!-- header -->
    <header1></header1>

    <section class="section1 bg-white p-0">
      <b-container>
        <b-row>
          <b-col lg="12" class="mt-5 mb-5">
            <h1>Clients</h1>
            <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Malesuada sed ipsum, ut quam volutpat, tortor.</p>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>

<script>
  import Header1 from './header1.vue'
  export default {
    components: {Header1},
    name: 'clients',
    metaInfo: {
      title: 'Clients pages'
    },
    data () {
      return {
        
      }
    }
    
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
