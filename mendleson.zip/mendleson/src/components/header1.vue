<template>
  <div class="text-left">
    <div v-bind:class="{headers: scrollHeader}">
      <header>
        <b-navbar toggleable="lg" type="dark" class="">
          <b-container>
            <b-navbar-brand class="" href="/"><b-img class="logo" fluid :src="require('@/assets/images/logo.png')"></b-img></b-navbar-brand>
            <b-navbar-toggle target="nav-collapse" class="text-dark bg-blue"></b-navbar-toggle>
            <b-collapse id="nav-collapse" is-nav>
              <b-navbar-nav class="ml-auto navs">
                <!--<b-nav-item class="navs" href="/">Home</b-nav-item>
                <b-nav-item class="navs" href="/about">About</b-nav-item>
                <b-nav-item class="navs" href="/contact">Contact</b-nav-item>-->
                <b-nav-item :key="i" v-for="(menu,i) in topMenus" :to="menu.link">{{menu.name}}</b-nav-item>
              </b-navbar-nav>
            </b-collapse>
          </b-container>
        </b-navbar>
      </header>
    </div>
  </div>
</template>

<script>
    export default {
      name: 'Header',
      data(){
        return{
          topMenus: [
            {'name':'About Us','link':'/about'},
            {'name':'Services','link':'/service'},
            {'name':'Team','link':'/team'},
            {'name':'Clients','link':'/client'},
            {'name':'Contact','link':'/contact'}
          ],

          // scroll header
          scrollHeader: false,
        }
      },

      mounted: function () {
        // scroll header
        window.addEventListener('scroll', this.scrollHeaders)
      },
      beforeDestroy: function () {
        // scroll header
        window.removeEventListener('scroll', this.scrollHeaders)
      },
      methods: {
        // scroll header
        scrollHeaders: function (e) {
          if(window.scrollY > 450){
            this.scrollHeader = true
          }else{
            this.scrollHeader = false
          }
        },
      }
    }
</script>

<style scoped>
    /* menu */
    ul li a{
      font-family: 'Roboto', sans-serif;
      font-style: normal;
      font-weight: 400 !important;
      font-size: 18px !important;
      line-height: 21px !important;
      /* identical to box height */
      color: #000000 !important;
      padding-right: 20px !important;
    }
    ul li a:hover{
      color: #1883b2 !important;
    }

    /* Logo */
    .logo{
     width: 295px;
     height: 8
     5px;
    }

      /* Logo responsive */
    @media screen and (max-width: 320px){
      .logo{
        width: 85px;
        height: 35px;
      }
    }

     /* headers */
    .headers{
      box-shadow: 0 0 60px 0 rgba(0,0,0, .13);
      background-color: #fff;
      width: 100%;
      top: 0;
      position: fixed; 
      padding: 0 !important;
      z-index: 999;
      animation-name: animatetop;
      animation-duration: 0.8s;
    }
    @keyframes animatetop{
      from{top: -300px; opacity: 0;}
      to{top: 0px; opacity: 1;}
    }
</style>