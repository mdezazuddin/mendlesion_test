<template>
  <div class="text-left bg-white">
    <!-- header Banner -->
    <section class="banner-section bg-white bg-banner-image p-0">
      <!-- header -->
      <header1></header1>

      <b-container class="margin-top1">
        <b-row>
          <b-col lg="6" class="mt-5">
            <b-img class="margin-top1" fluid :src="require('@/assets/images/Vector Smart Object21 1.png')"></b-img>
          </b-col>
          <b-col lg="6" class="mt-5">
            <h1>Mendleson Communication and Engagement</h1>
            <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Malesuada sed ipsum, ut quam volutpat, tortor.</p>
          </b-col>
        </b-row>
      </b-container>
    </section>

    <!-- section1 -->
    <section class="section1 py-5">
      <b-container>
        <b-row>
          <b-col lg="6" class="mt-5 align-self-center">
            <b-img fluid :src="require('@/assets/images/about us 1.png')"></b-img>
          </b-col>
          <b-col lg="6" class="mt-5">
            <h1 class="mb-0">ABOUT US</h1>
            <div class="col-5 px-0">
              <div class="progress" style="height:4px">
                <div class="progress-bar bg-secondary" style="width:25%;height:6px !important;"></div>
              </div>
            </div>
            <p class="mt-4">We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high quality approach. We deliver value, creaKvity, results and excepKonal levels of customer service and professionalism. We specialise in infrastructure development, energy and natural resources.</p>

            <b-row>
              <b-col lg="6" class="mt-3">
                <b-img fluid :src="require('@/assets/images/coomunication icon 1.png')"></b-img>
                <h5 class="mt-3 uppercase">Engagement</h5>
                <p class="mt-3">We are engagement specialists, who have led projects at all levels of the IAP2 spectrum. READ MORE</p>
              </b-col>
              <b-col lg="6" class="mt-3">
                <b-img fluid :src="require('@/assets/images/Enagagement icon 1.png')"></b-img>
                <h5 class="mt-3">Communications</h5>
                <p class="mt-3">We are award-winning leaders in communications and campaign management.READ MORE</p>
              </b-col>
            </b-row>
          </b-col>
        </b-row>
      </b-container>
    </section>

    <!-- section2 -->
    <section class="section2 py-5 bg-service-image">
      <b-container class="col-md-9 mx-auto">
        <b-row class="text-center">
          <b-col lg="12">
            <h1>SERVICES</h1>
            <div class="col-3 mx-auto px-0">
              <div class="progress" style="height:4px">
                <div class="progress-bar bg-secondary" style="width:25%;height:6px !important;"></div>
              </div>
            </div>
          </b-col>
        </b-row>
        <b-row>
          <b-col lg="6" class="text-md-right mt-5 align-self-center pr-md-5">
            <h2>Engagement</h2>
            <p class="mt-3">We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high quality approach. We deliver value, creaKvity, results and excepKonal levels of customer service and professionalism. We specialise in infrastructure development, energy and natural resources.</p>
          </b-col>
          <b-col lg="6" class="mt-5 align-self-center pl-md-5">
            <b-img class="ml-md-5" fluid :src="require('@/assets/images/Engagement vector 1.png')"></b-img>
          </b-col>

          <b-col lg="6" class="mt-5 align-self-center pr-md-5">
            <b-img fluid :src="require('@/assets/images/Coominucation vector 1.png')"></b-img>
          </b-col>
          <b-col lg="6" class="mt-5 align-self-center pl-md-5">
            <div class="pl-md-5">
              <h2>Communications</h2>
              <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Faucibus quam quis egestas orci. Scelerisque eu, vitae sapien, pellentesque et. Sit ac fames facilisis nibh faucibus. </p>
            </div>
          </b-col>

          <b-col lg="6" class="text-md-right mt-5 align-self-center pr-md-5">
            <h2>facilitation</h2>
            <p class="mt-3">We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high quality approach. We deliver value, creaKvity, results and excepKonal levels of customer service and professionalism. We specialise in infrastructure development, energy and natural resources.</p>
          </b-col>
          <b-col lg="6" class="mt-5 align-self-center pl-md-5">
            <b-img class="ml-md-5" fluid :src="require('@/assets/images/facilation vector 1.png')"></b-img>
          </b-col>

          <b-col lg="6" class="mt-5 align-self-center pr-md-5">
            <b-img fluid :src="require('@/assets/images/Consultation vector 1.png')"></b-img>
          </b-col>
          <b-col lg="6" class="mt-5 align-self-center pl-md-5">
            <div class="pl-md-5">
              <h2>Consultation and Research</h2>
              <p class="mt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Faucibus quam quis egestas orci. Scelerisque eu, vitae sapien, pellentesque et. Sit ac fames facilisis nibh faucibus. </p>
            </div>
          </b-col>

          <b-col lg="6" class="text-md-right mt-5 align-self-center pr-md-5">
            <h2>Traning & Mentoring</h2>
            <p class="mt-3">We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high quality approach. We deliver value, creaKvity, results and excepKonal levels of customer service and professionalism. We specialise in infrastructure development, energy and natural resources.</p>
          </b-col>
          <b-col lg="6" class="mt-5 align-self-center text-center pl-md-5">
            <b-img class="ml-md-5" fluid :src="require('@/assets/images/Training and vector1.png')"></b-img>
          </b-col>
        </b-row>
      </b-container>
    </section>

    <!-- section3 -->
    <div class="section3 bg-team-image py-5">
      <section class="section2 mt-5 pt-5">
        <b-container class="col-md-9 mx-auto">
          <b-row class="text-center">
            <b-col lg="12">
              <h1>OUR TEAM</h1>
              <div class="col-3 mx-auto px-0">
                <div class="progress" style="height:4px">
                  <div class="progress-bar bg-secondary" style="width:25%;height:6px !important;"></div>
                </div>
              </div>
            </b-col>
          </b-row>
          <b-row class="text-center">
            <b-col md="4" class="mt-5">
              <div class="hvr-float">
                <b-img fluid :src="require('@/assets/images/Person 1img1.png')"></b-img>
                <p class="mt-3"><a href="#" class="text-hvr1">Jessica D’suza</a></p>
              </div>
            </b-col>
            <b-col md="4" class="mt-5">
              <div class="hvr-float">
                <b-img fluid :src="require('@/assets/images/Person 2 img 1.png')"></b-img>
                <p class="mt-3"><a href="#" class="text-hvr1">Johny Williams</a></p>
              </div>
            </b-col>
            <b-col md="4" class="mt-5">
              <div class="hvr-float">
                <b-img fluid :src="require('@/assets/images/Person 3 img 1.png')"></b-img>
                <p class="mt-3"><a href="#" class="text-hvr1">Sanya R,</a></p>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </section>

      <!-- section4 -->
      <section class="section4 py-5 mt-5">
        <b-container class="col-md-9 mx-auto">
          <b-row class="text-center">
            <b-col lg="12">
              <h1>OUR PROJECTS</h1>
              <div class="col-4 mx-auto px-0">
                <div class="progress" style="height:4px">
                  <div class="progress-bar bg-secondary" style="width:25%;height:6px !important;"></div>
                </div>
              </div>
            </b-col>
          </b-row>
          <b-row>
            <b-col md="6" class="mt-5">
              <a href="#"><b-img fluid :src="require('@/assets/images/Our Project_1 img1.png')"></b-img></a>
            </b-col>
            <b-col md="6" class="mt-5">
              <a href="#">
                <div class="con5">
                  <b-img fluid :src="require('@/assets/images/Our Project _2 img1.png')"></b-img>
                  <div class="overlay5">
                      <div class="text5">
                        <h3 class="text-white">PROJECTS NAME</h3>
                      </div>
                  </div>
                </div>
              </a>
              <a href="#">
                <div class="con5 mt-3 pt-1">
                  <b-img fluid :src="require('@/assets/images/Our Project_3 img1.png')"></b-img>
                  <div class="overlay5">
                      <div class="text5">
                        <h3 class="text-white">PROJECTS NAME</h3>
                      </div>
                  </div>
                </div>
              </a>
            </b-col>
          </b-row>
        </b-container>
      </section>
    </div>

    <!-- section5 -->
    <section class="section5 pb-5 bg-client-image">
      <b-container class="col-md-9 mx-auto py-5">
        <b-row class="text-center">
          <b-col lg="12">
            <h1>OUR CLIENTS</h1>
            <div class="col-4 mx-auto px-0">
              <div class="progress" style="height:4px">
                <div class="progress-bar bg-secondary" style="width:25%;height:6px !important;"></div>
              </div>
            </div>
          </b-col>
        </b-row>
        <b-row>
          <b-col lg="2" sm="4" class="mt-5 text-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/Layer 19.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/Layer 20.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center align-self-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/1280px-Brigitte-Logo.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/Layer 22.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center align-self-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/BHP_2017_logo.png')"></b-img></a>
          </b-col>
        </b-row>

        <b-row>
          <b-col lg="2" sm="4" class="mt-5 text-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/Layer 21.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center align-self-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/Layer 23.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center align-self-center mx-auto">
           <a class="hvr-grow" href="#"> <b-img fluid :src="require('@/assets/images/Layer 24.png')"></b-img></a>
          </b-col>
          <b-col lg="2" sm="4" class="mt-5 text-center align-self-center mx-auto">
            <a class="hvr-grow" href="#"><b-img fluid :src="require('@/assets/images/MelbourneWaterLogo-1024x282.png')"></b-img></a>
          </b-col>
        </b-row>
      </b-container>
    </section>
  </div>
</template>

<script>
  // header import
  import Header1 from './header1.vue'
  export default {
    components: {Header1},
    metaInfo: {
      title: 'Home pages'
    },
    data(){
      return{
        
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  /* banner bg images */
  .bg-banner-image{background: url(../assets/images/Asset1.png) left top no-repeat, url(../assets/images/Asset2.png) right top no-repeat, url(../assets/images/Assets3.png) left bottom no-repeat, url(../assets/images/Assets4.png) right bottom no-repeat, url(../assets/images/Graphic1.png) right bottom no-repeat;
  background-size: 119px 111px, 359px 376px, 266px 580px, 207px 249px, 1403px 789.19px;}

  /* bg service images */
  .bg-service-image{background: url(../assets/images/Asset5.png) left top no-repeat, url(../assets/images/Asset7.png) left center no-repeat, url(../assets/images/Asset6.png) right center no-repeat, url(../assets/images/Asset8.png) right bottom no-repeat;
  background-position-y: 0, 1000px, 500px, 1400px;
  background-size: 366px 431px, 259px 471px, 250px 431px, 336px 431px;}

  /* bg team images */
  .bg-team-image{background: url(../assets/images/Asset5.png) left top no-repeat, url(../assets/images/Asset8.png) right center no-repeat;
  background-position-y: 0, 400px;
  background-size: 366px 431px, 371.17px 476.12px;}

  /* bg client images */
   .bg-client-image{background: url(../assets/images/Assets9.png) left top no-repeat;
  background-size: 179px 404px,}
</style>
